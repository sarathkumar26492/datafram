package com.org.dataframe.sparksessiondf

import org.apache.spark.sql.SparkSession

object demo {

  def main(args: Array[String]) = {

    System.setProperty("hadoop.home.dir", "E://hadoop_home")
    val spark = SparkSession.builder().master("local").appName("Spark Demo").getOrCreate()
    val inputdf = spark.read.json("C://Users//willb//OneDrive//Desktop//people.json")

    inputdf.printSchema()
    inputdf.show()

    val outpudf = inputdf.filter("age==30").select("age", "name").show()

    inputdf.filter("age > 1").show()
    inputdf.select("name", "age").groupBy("age", "name").count().show()

    inputdf.createOrReplaceTempView("employee")
    val sqlDS = spark.sql("select * from employee").show()
    inputdf.select("name").show()

    inputdf.createTempView("people")

    val using_global = spark.sql("select * from people")
          
    val sssql= inputdf.sqlContext.sql("select * from people")

    sssql.show()
  }

}